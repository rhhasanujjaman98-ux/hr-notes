# HR Notes

Offline Android app: employee notes, leave tracking (with yearly balance) and interview notes.
Languages: English, বাংলা, हिन्दी, العربية (RTL supported). Data stays on the device.

## Get the APK
1. Push this project to a GitHub repo (branch `main`).
2. Open the **Actions** tab -> **Build APK** (runs on every push, or press *Run workflow*).
3. When it finishes, download the **HR-Notes-apk** artifact (contains `app-debug.apk`).
4. Copy the APK to your phone and install it (allow "install unknown apps").

Local build (needs Android SDK + JDK 17 + Gradle 8.7): `gradle assembleDebug`.
